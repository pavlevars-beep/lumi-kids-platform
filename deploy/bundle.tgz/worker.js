// worker/lib.ts
var esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var clean = (v, max = 200) => typeof v === "string" ? v.trim().slice(0, max) : "";
var siteUrl = (env) => (env.SITE_URL || "https://lumikids.rs").replace(/\/$/, "");
async function sendEmail(env, msg) {
  if (!env.RESEND_API_KEY) return { ok: false, error: "Slanje mejlova nije pode\u0161eno (nedostaje RESEND_API_KEY)." };
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, "content-type": "application/json" },
    body: JSON.stringify({
      from: env.FROM_EMAIL || "Lumi Kids Studio <info@lumikids.rs>",
      to: Array.isArray(msg.to) ? msg.to : [msg.to],
      subject: msg.subject,
      html: msg.html,
      text: msg.text,
      reply_to: msg.replyTo || env.REPLY_TO || void 0,
      tags: msg.tags
    })
  });
  const data = await res.json().catch(() => ({}));
  return res.ok ? { ok: true, id: data.id } : { ok: false, error: data.message || `Resend gre\u0161ka ${res.status}` };
}

// worker/emails.ts
var BRAND = {
  ink: "#0f2a44",
  ink2: "#3d5368",
  ink3: "#6b7d8f",
  brand: "#0277bd",
  deep: "#0b3a66",
  bg: "#f3f6f9",
  line: "#e3e8ee",
  tint: "#e8f6fe",
  yellow: "#ffd700"
};
var templates = [
  {
    key: "prvi-kontakt",
    hero: "prvi-kontakt",
    heroAlt: "Roditelji i deca zajedno na Lumi Kids radionici",
    label: "Prvi kontakt \u2014 firma (HR)",
    audience: "firma",
    subject: "Program za decu zaposlenih \u2014 {firma}",
    preheader: "Radionice, prijem, fotografisanje i pokloni \u2014 mi organizujemo sve, vi samo potvrdite termin.",
    blocks: [
      { p: "{pozdrav}" },
      { p: "Javljamo se iz Lumi Kids Studija iz Kragujevca. Organizujemo programe za decu zaposlenih po principu <b>klju\u010D u ruke</b> \u2014 Kids Day, Dan porodice, novogodi\u0161nje i prazni\u010Dne programe, u va\u0161em ili u na\u0161em prostoru." },
      { p: "HR timovima najvi\u0161e zna\u010Di to \u0161to dobijaju jednog partnera za ceo doga\u0111aj:" },
      { list: [
        "koncept i satnicu programa prilago\u0111enu uzrastu i broju dece",
        "stru\u010Dne voditelje radionica (nauka, muzika, ples, robotika, govor\u2026) i sav materijal",
        "posebne senzorne i muzi\u010Dke radionice za bebe i decu do 4 godine, uz roditelja",
        "prijem, bed\u017Eeve, koordinatora i zajedni\u010Dko finale",
        "profesionalno fotografisanje doga\u0111aja i online galeriju sa fotografijama",
        "osve\u017Eenje, poklone i dekoraciju \u2014 po va\u0161em bud\u017Eetu"
      ] },
      { boxes: [
        { title: "120 min", text: "tipi\u010Dan program za 30\u201340 dece" },
        { title: "2 grupe", text: "po uzrastu, bez \u010Dekanja u redu" },
        { title: "48 h", text: "do predloga programa i ponude" }
      ] },
      { photos: [["radionica", "Deca sama izvode oglede"], ["osvezenje", "Osve\u017Eenje i detalji"]] },
      { p: "Ako u narednim mesecima planirate doga\u0111aj za zaposlene i njihovu decu, rado \u0107emo vam poslati predlog programa sa satnicom i ponudom u paketima \u2014 bez obaveze." },
      { cta: ["Pogledajte \u0161ta sve uklju\u010Dujemo", "{site}/?utm_source=email&utm_campaign=prvi-kontakt#usluge"] },
      { p: "Da li biste imali 10 minuta za kratak razgovor slede\u0107e nedelje?" }
    ]
  },
  {
    key: "novogodisnji",
    hero: "novogodisnji",
    heroAlt: "Deca i roditelji na radionici u Lumi Kids studiju",
    label: "Novogodi\u0161nji program \u2014 firma",
    audience: "firma",
    subject: "Novogodi\u0161nji program za decu zaposlenih \u2014 slobodni termini za decembar",
    preheader: "Nau\u010Dna radionica, Deda Mraz, pokloni i fotografije sa doga\u0111aja u online galeriji.",
    blocks: [
      { p: "{pozdrav}" },
      { p: "Decembar je za mnoge kompanije vreme kada se zaposlenima i njihovoj deci ka\u017Ee hvala. Mi preuzimamo kompletnu organizaciju novogodi\u0161njeg programa \u2014 va\u0161 tim samo potvrdi datum i broj dece." },
      { h: "Primer programa (\u224835 dece, 4\u201310 god., 120 min)" },
      { timeline: [
        ["0:00", "Do\u010Dek, bed\u017Eevi sa imenom, okupljanje uz muziku"],
        ["0:15", "Grupa A: radionica \u201EVilenja\u010Dka laboratorija\u201C \xB7 Grupa B: fotografisanje sa Deda Mrazom"],
        ["0:55", "Pauza uz sok i grickalice, zamena grupa"],
        ["1:05", "Grupe se menjaju"],
        ["1:45", "Finale: Deda Mraz deli poklone, grupna fotografija"]
      ] },
      { photos: [["voditeljka", "Voditelji za svaku grupu"], ["najmladji", "Program i za najmla\u0111e"]] },
      { p: "Fotograf bele\u017Ei ceo program, a fotografije su <b>dostupne u online galeriji</b> u roku od 5 radnih dana \u2014 link \u0161aljemo vama, a vi ga prosle\u0111ujete zaposlenima. Nudimo tri paketa (Start, Standard, Premium): za ~35 dece paketi po\u010Dinju od 145.000 RSD, a za ve\u0107i broj dece organizujemo vi\u0161e grupa ili termina." },
      { cta: ["Po\u0161aljite upit za decembar", "{site}/?utm_source=email&utm_campaign=novogodisnji#upit"] },
      { p: "Termini za decembar se brzo popunjavaju \u2014 ako vam odgovara, javite okvirni datum i broj dece pa \u0161aljemo predlog u roku od 48 sati." }
    ]
  },
  {
    key: "vrtic",
    hero: "vrtic",
    heroAlt: "Grupa dece na radionici za stolom",
    label: "Prvi kontakt \u2014 vrti\u0107 / \u0161kola",
    audience: "vrtic",
    subject: "Radionice za va\u0161e grupe \u2014 Lumi Kids Studio",
    preheader: "Dolazimo sa kompletnom opremom i stru\u010Dnim voditeljima.",
    blocks: [
      { p: "{pozdrav}" },
      { p: "Lumi Kids Studio izvodi kreativno-edukativne radionice za decu od beba do 10 godina \u2014 senzorne i muzi\u010Dke radionice za bebe uz roditelja, nauka i eksperimenti, muzika, ples, robotika, \u010Ditanje i govor, priprema za \u0161kolu." },
      { list: [
        "dolazimo u va\u0161 prostor sa svim materijalom",
        "radionicu vodi stru\u010Dna osoba iz oblasti (pedagog, logoped, defektolog, muzi\u010Dar\u2026)",
        "svako dete nosi ku\u0107i ne\u0161to \u0161to je samo napravilo",
        "pogodno za tematske dane, priredbe i serijale radionica"
      ] },
      { cta: ["Pogledajte radionice", "{site}/radionice?utm_source=email&utm_campaign=vrtic"] },
      { p: "Rado \u0107emo predlo\u017Eiti program za va\u0161e grupe \u2014 dovoljno je da nam javite uzrast i broj dece." }
    ]
  },
  {
    key: "podsetnik",
    hero: "podsetnik",
    heroAlt: "Tata i deca stvaraju zajedno",
    label: "Podsetnik (follow-up)",
    audience: "sve",
    subject: "Re: program za decu \u2014 {firma}",
    preheader: "Kratko podse\u0107anje na na\u0161u prethodnu poruku.",
    blocks: [
      { p: "{pozdrav}" },
      { p: "Samo kratko podse\u0107anje na na\u0161u prethodnu poruku o programu za decu. Ako vam je trenutno zanimljivo, mo\u017Eemo da po\u0161aljemo konkretan predlog sa satnicom i cenom za va\u0161 broj dece \u2014 potrebna su nam samo dva podatka: okvirni datum i broj dece." },
      { p: "Ako ovo nije prava osoba za ovu temu, bili bismo zahvalni ako nas uputite na kolegu iz HR-a." },
      { cta: ["Po\u0161aljite upit", "{site}/?utm_source=email&utm_campaign=podsetnik#upit"] }
    ]
  },
  {
    key: "hvala",
    hero: "hvala",
    heroAlt: "Pun studio dece i roditelja",
    label: "Zahvalnica posle doga\u0111aja",
    audience: "sve",
    subject: "Hvala na saradnji \u2014 {firma}",
    preheader: "Fotografije sti\u017Eu uskoro, a va\u0161e mi\u0161ljenje nam mnogo zna\u010Di.",
    blocks: [
      { p: "{pozdrav}" },
      { p: "Hvala vam na poverenju \u2014 bilo nam je zadovoljstvo da budemo deo va\u0161eg doga\u0111aja. Fotografije sti\u017Eu porodicama u roku od 5 radnih dana." },
      { p: "Mnogo bi nam zna\u010Dilo kratko mi\u0161ljenje: \u0161ta vam se najvi\u0161e dopalo i \u0161ta bismo slede\u0107i put mogli bolje? Dovoljno je da odgovorite na ovaj mejl." },
      { p: "Ako planirate novi doga\u0111aj (Dan porodice, De\u010Dja nedelja, kraj \u0161kolske godine), javite se \u2014 za ponovljene saradnje pripremamo novi program i posebne uslove." }
    ]
  }
];
var confirmationTemplate = {
  key: "potvrda-upita",
  hero: "potvrda",
  heroAlt: "Devoj\u010Dica izvodi ogled na radionici",
  label: "Automatska potvrda upita",
  audience: "sve",
  subject: "Primili smo va\u0161 upit \u2014 Lumi Kids Studio",
  preheader: "Javljamo se u roku od 48 sati sa predlogom programa.",
  blocks: [
    { p: "{pozdrav}" },
    { p: "Hvala na upitu! Primili smo ga i javljamo vam se u roku od <b>48 sati</b> sa predlogom programa, satnicom i ponudom." },
    { p: "Ako \u017Eelite ne\u0161to da dodate \u2014 datum, broj dece, posebne \u017Eelje \u2014 samo odgovorite na ovaj mejl." },
    { cta: ["Pogledajte na\u0161e radionice", "{site}/radionice"] }
  ]
};
var templateByKey = (key) => templates.find((t) => t.key === key) || (key === confirmationTemplate.key ? confirmationTemplate : void 0);
function fill(s, v, site) {
  const pozdrav = v.ime ? `Po\u0161tovani/a ${v.ime},` : "Po\u0161tovani,";
  return s.replaceAll("{pozdrav}", pozdrav).replaceAll("{ime}", v.ime || "").replaceAll("{firma}", v.firma || "va\u0161 tim").replaceAll("{grad}", v.grad || "").replaceAll("{site}", site);
}
function renderTemplate(t, vars, site, subjectOverride) {
  const escVars = { ime: esc(vars.ime || ""), firma: esc(vars.firma || ""), grad: esc(vars.grad || "") };
  const B = BRAND;
  const pStyle = `margin:0 0 16px;font-size:16px;line-height:1.6;color:${B.ink2}`;
  const blocks = [...t.blocks];
  if (vars.licno?.trim()) {
    blocks.splice(1, 0, { p: esc(vars.licno.trim()).replace(/\n/g, "<br>") });
  }
  const body = blocks.map((b) => {
    if ("p" in b) return `<p style="${pStyle}">${fill(b.p, escVars, site)}</p>`;
    if ("h" in b) return `<h3 style="margin:8px 0 12px;font-size:17px;color:${B.ink}">${fill(b.h, escVars, site)}</h3>`;
    if ("list" in b)
      return `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 18px">${b.list.map((li) => `<tr><td valign="top" style="padding:3px 10px 3px 0;color:#5c8f22;font-weight:bold">\u2713</td><td style="padding:3px 0;font-size:15px;line-height:1.5;color:${B.ink2}">${fill(li, escVars, site)}</td></tr>`).join("")}</table>`;
    if ("timeline" in b)
      return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 18px;background:${B.bg};border-radius:12px">${b.timeline.map(([tm, tx]) => `<tr><td valign="top" style="padding:10px 0 10px 16px;width:52px;font-weight:bold;color:${B.brand};font-size:14px">${tm}</td><td style="padding:10px 16px 10px 0;font-size:14px;line-height:1.5;color:${B.ink2}">${fill(tx, escVars, site)}</td></tr>`).join("")}</table>`;
    if ("boxes" in b)
      return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:4px 0 20px"><tr>${b.boxes.map((x) => `<td width="${Math.floor(100 / b.boxes.length)}%" style="padding:0 4px"><div style="background:${B.tint};border-radius:12px;padding:14px 10px;text-align:center"><div style="font-size:20px;font-weight:800;color:${B.deep}">${x.title}</div><div style="font-size:13px;color:${B.ink3};margin-top:4px">${x.text}</div></div></td>`).join("")}</tr></table>`;
    if ("photos" in b)
      return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:4px 0 20px"><tr>${b.photos.map(([img, cap]) => `<td width="50%" valign="top" style="padding:0 4px"><img src="${site}/img/email/${img}.jpg" width="260" alt="${esc(cap)}" style="display:block;width:100%;height:auto;border:0;border-radius:12px"><div style="font-size:13px;color:${B.ink3};margin-top:6px;text-align:center">${esc(cap)}</div></td>`).join("")}</tr></table>`;
    if ("cta" in b)
      return `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:6px 0 22px"><tr><td style="background:${B.brand};border-radius:999px"><a href="${fill(b.cta[1], escVars, site)}" style="display:inline-block;padding:13px 26px;font-size:15px;font-weight:bold;color:#ffffff;text-decoration:none">${b.cta[0]} \u2192</a></td></tr></table>`;
    return "";
  }).join("");
  const subject = fill(subjectOverride || t.subject, { ime: vars.ime, firma: vars.firma, grad: vars.grad }, site);
  const html = `<!doctype html><html lang="sr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(subject)}</title></head>
<body style="margin:0;padding:0;background:${B.bg};font-family:Nunito,'Segoe UI',Arial,sans-serif">
<div style="display:none;max-height:0;overflow:hidden;opacity:0">${esc(t.preheader)}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${B.bg}"><tr><td align="center" style="padding:28px 12px">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:18px;overflow:hidden;border:1px solid ${B.line}">
<tr><td style="padding:22px 32px 18px"><img src="${site}/img/email/logo.png" width="170" alt="Lumi Kids Studio" style="display:block;border:0;height:auto;max-width:170px"></td></tr>
<tr><td style="height:5px;line-height:5px;font-size:0;background:linear-gradient(90deg,#ff4b4b,#ff9e3d,#ffd700,#8bc34a,#03a9f4,#0277bd);background-color:#03a9f4">&nbsp;</td></tr>
<tr><td style="padding:0"><img src="${site}/img/email/${t.hero}.jpg" width="600" alt="${esc(t.heroAlt)}" style="display:block;width:100%;max-width:600px;height:auto;border:0"></td></tr>
<tr><td style="padding:30px 32px 10px">${body}
<p style="margin:8px 0 0;font-size:15px;line-height:1.6;color:${B.ink2}">Srda\u010Dan pozdrav,<br><b style="color:${B.ink}">Tijana Varsakovi\u0107</b><br>Lumi Kids Studio \xB7 <a href="tel:+381693042721" style="color:${B.brand};text-decoration:none">+381 69 304 2721</a></p></td></tr>
<tr><td style="padding:22px 32px;background:${B.deep};color:#c9dbeb;font-size:13px;line-height:1.6">
<b style="color:#ffffff">Lumi Kids Studio</b> \xB7 de\u010Dji programi po porud\u017Ebini \xB7 Kragujevac i Beograd<br>
<a href="${site}" style="color:#ffffff">lumikids.rs</a> \xB7 <a href="https://www.instagram.com/studiolumikids/" style="color:#ffffff">@studiolumikids</a><br>
<span style="color:#9fb6cc">Ako ne \u017Eelite da vam se ubudu\u0107e javljamo, samo odgovorite sa \u201Eodjava\u201C.</span>
</td></tr></table></td></tr></table></body></html>`;
  const text = blocks.map((b) => {
    if ("p" in b) return fill(b.p, { ime: vars.ime, firma: vars.firma, grad: vars.grad }, site).replace(/<[^>]+>/g, "");
    if ("h" in b) return b.h;
    if ("list" in b) return b.list.map((l) => `- ${l}`).join("\n");
    if ("timeline" in b) return b.timeline.map(([a, c]) => `${a}  ${c}`).join("\n");
    if ("boxes" in b) return b.boxes.map((x) => `${x.title} \u2014 ${x.text}`).join("\n");
    if ("photos" in b)
      return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:4px 0 20px"><tr>${b.photos.map(([img, cap]) => `<td width="50%" valign="top" style="padding:0 4px"><img src="${site}/img/email/${img}.jpg" width="260" alt="${esc(cap)}" style="display:block;width:100%;height:auto;border:0;border-radius:12px"><div style="font-size:13px;color:${B.ink3};margin-top:6px;text-align:center">${esc(cap)}</div></td>`).join("")}</tr></table>`;
    if ("cta" in b) return `${b.cta[0]}: ${fill(b.cta[1], {}, site)}`;
    if ("photos" in b) return "";
    return "";
  }).join("\n\n") + "\n\nSrda\u010Dan pozdrav,\nTijana Varsakovi\u0107\nLumi Kids Studio \xB7 +381 69 304 2721\nlumikids.rs";
  return { subject, html, text };
}

// worker/inquiry.ts
var MAX = 2e3;
var list = (fd, key) => fd.getAll(key).map((v) => clean(v, 80)).filter(Boolean).join(", ");
function respond(req, status, body) {
  const wantsJson = (req.headers.get("accept") || "").includes("application/json");
  if (!wantsJson) {
    const target = status === 200 ? "/hvala" : "/#upit";
    return Response.redirect(new URL(target, req.url).toString(), 303);
  }
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" }
  });
}
async function handleInquiry(request, env) {
  let fd;
  try {
    fd = await request.formData();
  } catch {
    return respond(request, 400, { ok: false, error: "Neispravan zahtev." });
  }
  if (clean(fd.get("website"))) return respond(request, 200, { ok: true });
  if (env.TURNSTILE_SECRET) {
    const token = clean(fd.get("cf-turnstile-response"), 4096);
    const v = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      body: new URLSearchParams({
        secret: env.TURNSTILE_SECRET,
        response: token,
        remoteip: request.headers.get("CF-Connecting-IP") || ""
      })
    }).then((r) => r.json());
    if (!v.success) return respond(request, 400, { ok: false, error: "Provera nije uspela." });
  }
  const data = {
    client_type: clean(fd.get("client_type"), 60),
    occasion: clean(fd.get("occasion"), 80),
    organization: clean(fd.get("organization")),
    name: clean(fd.get("name"), 120),
    email: clean(fd.get("email"), 160),
    phone: clean(fd.get("phone"), 40),
    city: clean(fd.get("city"), 80),
    event_date: clean(fd.get("event_date"), 20),
    kids_count: Number.parseInt(clean(fd.get("kids_count"), 6), 10) || null,
    age_groups: list(fd, "age_groups"),
    location: clean(fd.get("location"), 80),
    services: list(fd, "services"),
    workshops: list(fd, "workshops"),
    budget: clean(fd.get("budget"), 60),
    message: clean(fd.get("message"), MAX),
    source_page: clean(fd.get("source_page"), 120)
  };
  if (!data.name || !data.client_type) {
    return respond(request, 400, { ok: false, error: "Unesite ime i izaberite ko organizuje." });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    return respond(request, 400, { ok: false, error: "Unesite ispravnu imejl adresu." });
  }
  if (!fd.get("consent")) {
    return respond(request, 400, { ok: false, error: "Potrebna je saglasnost za kontakt." });
  }
  const segmentMap = {
    "Firma": "firma",
    "Vrti\u0107 / \u0161kola": "vrtic",
    "Institucija / udru\u017Eenje": "institucija",
    "Ro\u0111endaonica / igraonica": "rodjendaonica",
    "Roditelj (ro\u0111endan)": "roditelj"
  };
  const cols = Object.keys(data);
  const ins = await env.DB.prepare(
    `INSERT INTO inquiries (${cols.join(", ")}) VALUES (${cols.map(() => "?").join(", ")})`
  ).bind(...Object.values(data)).run();
  const inquiryId = ins.meta.last_row_id;
  const summary = [
    data.occasion && `Povod: ${data.occasion}`,
    data.event_date && `Datum: ${data.event_date}`,
    data.kids_count && `Broj dece: ${data.kids_count}`,
    data.age_groups && `Uzrast: ${data.age_groups}`,
    data.location && `Lokacija: ${data.location}`,
    data.services && `Usluge: ${data.services}`,
    data.workshops && `Radionice: ${data.workshops}`,
    data.budget && `Bud\u017Eet: ${data.budget}`,
    data.message && `Poruka: ${data.message}`
  ].filter(Boolean).join("\n");
  const existing = await env.DB.prepare("SELECT id FROM leads WHERE lower(email) = lower(?)").bind(data.email).first();
  let leadId;
  if (existing) {
    leadId = existing.id;
    await env.DB.prepare(`UPDATE leads SET status = 'novo', inquiry_id = ?, updated_at = datetime('now'),
      phone = COALESCE(NULLIF(phone, ''), ?), contact_name = COALESCE(NULLIF(contact_name, ''), ?) WHERE id = ?`).bind(inquiryId, data.phone, data.name, leadId).run();
  } else {
    const r = await env.DB.prepare(`INSERT INTO leads (company, segment, city, contact_name, email, phone, source, status, inquiry_id)
      VALUES (?, ?, ?, ?, ?, ?, 'sajt', 'novo', ?)`).bind(data.organization || data.name, segmentMap[data.client_type] || "firma", data.city, data.name, data.email, data.phone, inquiryId).run();
    leadId = r.meta.last_row_id;
  }
  await env.DB.prepare(`INSERT INTO activities (lead_id, kind, subject, body) VALUES (?, 'upit', ?, ?)`).bind(leadId, `Upit sa sajta: ${data.client_type}`, summary).run();
  const site = siteUrl(env);
  const tasks = [];
  if (env.NOTIFY_EMAIL) {
    const labels = {
      client_type: "Ko organizuje",
      occasion: "Povod",
      organization: "Organizacija",
      name: "Ime",
      email: "Imejl",
      phone: "Telefon",
      city: "Grad",
      event_date: "Datum",
      kids_count: "Broj dece",
      age_groups: "Uzrast",
      location: "Lokacija",
      services: "Usluge",
      workshops: "Radionice",
      budget: "Bud\u017Eet",
      message: "Poruka",
      source_page: "Stranica"
    };
    const rows = Object.entries(data).filter(([, v]) => v !== "" && v !== null).map(([k, v]) => `<tr><td style="padding:4px 12px 4px 0;color:#6b7d8f;vertical-align:top"><b>${labels[k] ?? k}</b></td><td>${esc(String(v)).replace(/\n/g, "<br>")}</td></tr>`).join("");
    tasks.push(sendEmail(env, {
      to: env.NOTIFY_EMAIL.split(",").map((s) => s.trim()),
      replyTo: data.email,
      subject: `Novi upit: ${data.client_type}${data.organization ? ` \u2014 ${data.organization}` : ""} (${data.name})`,
      html: `<div style="font-family:Arial,sans-serif"><h2>Novi upit sa sajta</h2><table>${rows}</table>
        <p><a href="${site}/admin/leads/${leadId}">Otvori lead u CMS-u \u2192</a></p></div>`,
      tags: [{ name: "type", value: "notify" }]
    }));
  }
  const conf = renderTemplate(confirmationTemplate, { ime: data.name.split(" ")[0] }, site);
  tasks.push(
    sendEmail(env, { to: data.email, subject: conf.subject, html: conf.html, text: conf.text, tags: [{ name: "type", value: "confirmation" }] }).then(async (r) => {
      if (r.ok) await env.DB.prepare(`INSERT INTO activities (lead_id, kind, subject, meta) VALUES (?, 'mejl', ?, ?)`).bind(leadId, conf.subject, JSON.stringify({ template: "potvrda-upita", id: r.id })).run();
    })
  );
  await Promise.allSettled(tasks);
  return respond(request, 200, { ok: true });
}

// worker/auth.ts
var COOKIE = "lk_admin";
var MAX_AGE = 60 * 60 * 24 * 30;
var enc = new TextEncoder();
async function hmac(secret, data) {
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(data));
  return btoa(String.fromCharCode(...new Uint8Array(sig))).replace(/[+/=]/g, (c) => ({ "+": "-", "/": "_", "=": "" })[c]);
}
function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
var secretOf = (env) => env.SESSION_SECRET || env.ADMIN_PASSWORD || "";
async function isAuthed(req, env) {
  if (!env.ADMIN_PASSWORD) return false;
  const cookie = req.headers.get("cookie") || "";
  const m = cookie.match(new RegExp(`${COOKIE}=([^;]+)`));
  if (!m) return false;
  const [exp, sig] = decodeURIComponent(m[1]).split(".");
  if (!exp || !sig || Number(exp) < Date.now() / 1e3) return false;
  return safeEqual(sig, await hmac(secretOf(env), exp));
}
async function checkPassword(env, password) {
  if (!env.ADMIN_PASSWORD) return false;
  const k = secretOf(env);
  return safeEqual(await hmac(k, password), await hmac(k, env.ADMIN_PASSWORD));
}
async function sessionCookie(env) {
  const exp = String(Math.floor(Date.now() / 1e3) + MAX_AGE);
  const value = `${exp}.${await hmac(secretOf(env), exp)}`;
  return `${COOKIE}=${encodeURIComponent(value)}; Path=/admin; HttpOnly; Secure; SameSite=Lax; Max-Age=${MAX_AGE}`;
}
var clearCookie = `${COOKIE}=; Path=/admin; HttpOnly; Secure; SameSite=Lax; Max-Age=0`;
function sameOrigin(req) {
  const origin = req.headers.get("origin");
  if (!origin) return true;
  return new URL(origin).host === new URL(req.url).host;
}

// worker/admin.ts
var STATUSES = [
  { key: "novo", label: "Novi upit", color: "#ff4b4b" },
  { key: "za_kontakt", label: "Za kontakt", color: "#6b7d8f" },
  { key: "kontaktiran", label: "Kontaktiran", color: "#0288d1" },
  { key: "u_razgovoru", label: "U razgovoru", color: "#e07a10" },
  { key: "ponuda", label: "Ponuda poslata", color: "#b58b00" },
  { key: "potvrdjeno", label: "Potvr\u0111eno", color: "#5c8f22" },
  { key: "izgubljeno", label: "Izgubljeno", color: "#9aa7b4" }
];
var statusOf = (k) => STATUSES.find((s) => s.key === k) || STATUSES[1];
var SEGMENTS = {
  firma: "Firma",
  vrtic: "Vrti\u0107 / \u0161kola",
  institucija: "Institucija",
  rodjendaonica: "Ro\u0111endaonica",
  roditelj: "Roditelj"
};
var LEAD_FIELDS = ["company", "segment", "city", "website", "employees", "contact_name", "contact_role", "email", "phone", "source", "status", "value_rsd", "next_action_at", "notes", "marketing_consent", "priority", "channel", "program", "package", "reason", "linkedin", "contact_url"];
var PRIORITY_COLORS = { A: "#5c8f22", B: "#0288d1", C: "#9aa7b4", X: "#d92d20" };
var prio = (p) => p ? `<span class="pill" style="background:${PRIORITY_COLORS[p] || "#9aa7b4"}">${esc(p)}</span>` : "";
var CSS = `
:root{--ink:#0f2a44;--ink2:#3d5368;--ink3:#6b7d8f;--brand:#0277bd;--deep:#0b3a66;--bg:#f3f6f9;--line:#e3e8ee;--ok:#5c8f22;--bad:#d92d20}
*{box-sizing:border-box}body{margin:0;font-family:Nunito,system-ui,'Segoe UI',sans-serif;background:var(--bg);color:var(--ink);font-size:15px}
a{color:var(--brand)}header{background:var(--deep);color:#fff}header .in{display:flex;gap:18px;align-items:center;max-width:1280px;margin:0 auto;padding:12px 20px;flex-wrap:wrap}
header img{height:34px;background:#fff;border-radius:8px;padding:3px 6px}header nav{display:flex;gap:16px;flex:1;flex-wrap:wrap}header a{color:#fff;text-decoration:none;font-weight:700}
main{max-width:1280px;margin:0 auto;padding:24px 20px 60px}h1{font-size:1.6rem;margin:0 0 16px}h2{font-size:1.15rem;margin:0 0 12px}
.card{background:#fff;border:1px solid var(--line);border-radius:14px;padding:18px}.grid{display:grid;gap:16px}
.g2{grid-template-columns:1.3fr 1fr}@media(max-width:900px){.g2{grid-template-columns:1fr}}
.pipe{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}.pipe a{flex:1;min-width:120px;background:#fff;border:1px solid var(--line);border-radius:12px;padding:10px 12px;text-decoration:none;color:var(--ink)}
.pipe a b{display:block;font-size:1.4rem}.pipe a.on{outline:2px solid var(--brand)}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:14px;overflow:hidden;border:1px solid var(--line)}
th,td{text-align:left;padding:10px 12px;border-bottom:1px solid var(--line);vertical-align:top}th{font-size:.78rem;text-transform:uppercase;letter-spacing:.05em;color:var(--ink3);background:#fafbfc}
tr:hover td{background:#fafcff}.muted{color:var(--ink3);font-size:.88rem}.late{color:var(--bad);font-weight:800}
.pill{display:inline-block;padding:3px 10px;border-radius:999px;color:#fff;font-size:.8rem;font-weight:800;white-space:nowrap}
.tag{display:inline-block;padding:2px 8px;border-radius:6px;background:var(--bg);font-size:.8rem;color:var(--ink2)}
form.inline{display:flex;gap:8px;flex-wrap:wrap;align-items:end;margin-bottom:14px}
label{display:block;font-weight:700;font-size:.85rem;margin-bottom:10px}label span{display:block;margin-bottom:4px}
input,select,textarea{width:100%;font:inherit;padding:9px 11px;border:1.5px solid var(--line);border-radius:10px;background:#fff;color:var(--ink)}
textarea{min-height:90px;resize:vertical}.row{display:grid;grid-template-columns:1fr 1fr;gap:10px}.row3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px}
form.inline label{margin:0}form.inline input,form.inline select{width:auto;min-width:160px}
.btn{display:inline-block;background:var(--brand);color:#fff;border:0;border-radius:999px;padding:10px 18px;font:inherit;font-weight:800;cursor:pointer;text-decoration:none}
.btn.ghost{background:#fff;color:var(--ink);border:1.5px solid var(--line)}.btn.sm{padding:6px 12px;font-size:.85rem}
.flash{padding:12px 14px;border-radius:10px;margin-bottom:16px;font-weight:700}.flash.ok{background:#f1f8e8;color:#3f7a12}.flash.err{background:#fff0ee;color:#b42318}
.tl{list-style:none;margin:0;padding:0}.tl li{border-left:3px solid var(--line);padding:4px 0 14px 14px;position:relative}
.tl li:before{content:'';position:absolute;left:-7px;top:8px;width:11px;height:11px;border-radius:50%;background:var(--brand)}
.tl li.mejl:before{background:#e07a10}.tl li.upit:before{background:#ff4b4b}.tl li.status:before{background:#5c8f22}
.tl pre{white-space:pre-wrap;font:inherit;margin:6px 0 0;color:var(--ink2)}.actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.check{display:flex;gap:8px;align-items:center}.check input{width:auto}
`;
function page(title, body, opts = {}) {
  const nav = opts.nav === false ? "" : `<nav><a href="/admin">Leadovi</a><a href="/admin/leads/new">+ Novi lead</a><a href="/admin/import">Uvoz liste</a><a href="/admin/templates">Mejl \u0161abloni</a><a href="/admin/export.csv">Izvoz CSV</a></nav><a href="/admin/logout">Odjava</a>`;
  const flash = opts.flash ? `<div class="flash ok">${esc(opts.flash)}</div>` : opts.err ? `<div class="flash err">${esc(opts.err)}</div>` : "";
  return new Response(
    `<!doctype html><html lang="sr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>${esc(title)} \xB7 Lumi CMS</title>
<link rel="icon" href="/favicon.png"><style>${CSS}</style></head><body><header><div class="in"><a href="/admin"><img src="/img/logo.png" alt="Lumi Kids"></a>${nav}</div></header><main>${flash}${body}</main></body></html>`,
    { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store", "x-robots-tag": "noindex" } }
  );
}
var redirect = (to, headers = {}) => new Response(null, { status: 303, headers: { Location: to, ...headers } });
var pill = (status) => {
  const s = statusOf(status);
  return `<span class="pill" style="background:${s.color}">${s.label}</span>`;
};
var fmtDate = (d) => d ? (/* @__PURE__ */ new Date(d.replace(" ", "T") + (d.length > 10 && !d.endsWith("Z") ? "Z" : ""))).toLocaleString("sr-Latn-RS", { day: "2-digit", month: "2-digit", year: "numeric", ...d.length > 10 ? { hour: "2-digit", minute: "2-digit" } : {}, timeZone: "Europe/Belgrade" }) : "";
var today = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
var options = (pairs, sel) => pairs.map(([v, l]) => `<option value="${esc(v)}"${v === sel ? " selected" : ""}>${esc(l)}</option>`).join("");
async function handleAdmin(req, env) {
  const url = new URL(req.url);
  const path = url.pathname.replace(/\/+$/, "") || "/admin";
  if (path === "/admin/login") return login(req, env);
  if (path === "/admin/logout") return redirect("/admin/login", { "Set-Cookie": clearCookie });
  if (!await isAuthed(req, env)) return redirect("/admin/login");
  if (req.method === "POST" && !sameOrigin(req)) return new Response("Forbidden", { status: 403 });
  const flash = url.searchParams.get("ok") || void 0;
  const err = url.searchParams.get("err") || void 0;
  if (path === "/admin") return list2(url, env, flash, err);
  if (path === "/admin/leads/new") return req.method === "POST" ? createLead(req, env) : leadForm(null, env);
  if (path === "/admin/import") return req.method === "POST" ? importCsv(req, env) : importForm(flash, err);
  if (path === "/admin/export.csv") return exportCsv(env);
  if (path === "/admin/templates") return templatesPage(env);
  const prev = path.match(/^\/admin\/templates\/([\w-]+)$/);
  if (prev) return previewTemplate(prev[1], url, env);
  const m = path.match(/^\/admin\/leads\/(\d+)(?:\/(\w+))?$/);
  if (m) {
    const id = Number(m[1]);
    const action = m[2];
    if (!action) return req.method === "POST" ? updateLead(id, req, env) : leadDetail(id, env, flash, err);
    if (req.method !== "POST") return redirect(`/admin/leads/${id}`);
    if (action === "note") return addNote(id, req, env);
    if (action === "email") return sendLeadEmail(id, req, env);
    if (action === "delete") return deleteLead(id, env);
  }
  return page("Nije prona\u0111eno", "<h1>Stranica ne postoji</h1>");
}
async function login(req, env) {
  let err = "";
  if (!env.ADMIN_PASSWORD) err = "Admin lozinka jo\u0161 nije pode\u0161ena (secret ADMIN_PASSWORD).";
  if (req.method === "POST" && env.ADMIN_PASSWORD) {
    const fd = await req.formData();
    if (await checkPassword(env, clean(fd.get("password"), 200))) {
      return redirect("/admin", { "Set-Cookie": await sessionCookie(env) });
    }
    await new Promise((r) => setTimeout(r, 600));
    err = "Pogre\u0161na lozinka.";
  }
  return page("Prijava", `<div class="card" style="max-width:380px;margin:60px auto"><h1>Lumi CMS</h1>
    <form method="post"><label><span>Lozinka</span><input type="password" name="password" autofocus required></label><button class="btn">Prijavi se</button></form></div>`, { err, nav: false });
}
async function list2(url, env, flash, err) {
  const status = url.searchParams.get("status") || "";
  const segment = url.searchParams.get("segment") || "";
  const q = url.searchParams.get("q") || "";
  const priority = url.searchParams.get("priority") || "";
  const region = url.searchParams.get("region") || "";
  const sort = url.searchParams.get("sort") || "skor";
  const where = [];
  const binds = [];
  if (status) {
    where.push("status = ?");
    binds.push(status);
  } else where.push("status NOT IN ('izgubljeno')");
  if (segment) {
    where.push("segment = ?");
    binds.push(segment);
  }
  if (priority) {
    where.push("priority = ?");
    binds.push(priority);
  }
  if (region) {
    where.push("region = ?");
    binds.push(region);
  }
  if (q) {
    where.push("(company LIKE ? OR contact_name LIKE ? OR email LIKE ? OR city LIKE ? OR notes LIKE ? OR sector LIKE ? OR reason LIKE ?)");
    binds.push(...Array(7).fill(`%${q}%`));
  }
  const sql = `SELECT * FROM leads ${where.length ? "WHERE " + where.join(" AND ") : ""}
    ORDER BY CASE status WHEN 'novo' THEN 0 ELSE 1 END, ${sort === "sledeci" ? "CASE WHEN next_action_at IS NULL OR next_action_at = '' THEN 1 ELSE 0 END, next_action_at, score DESC" : "score DESC, company"} LIMIT 500`;
  const [{ results: leads }, { results: counts }, { results: regions }] = await Promise.all([
    env.DB.prepare(sql).bind(...binds).all(),
    env.DB.prepare("SELECT status, COUNT(*) AS n, COALESCE(SUM(value_rsd),0) AS v FROM leads GROUP BY status").all(),
    env.DB.prepare("SELECT region, COUNT(*) AS n FROM leads WHERE region IS NOT NULL AND region <> '' GROUP BY region ORDER BY n DESC").all()
  ]);
  const cnt = Object.fromEntries(counts.map((c) => [c.status, c]));
  const qs = (s) => `/admin?status=${s}${segment ? `&segment=${segment}` : ""}`;
  const pipe = STATUSES.map((s) => `<a href="${qs(s.key)}" class="${status === s.key ? "on" : ""}" style="border-top:4px solid ${s.color}"><b>${cnt[s.key]?.n || 0}</b><span class="muted">${s.label}${cnt[s.key]?.v ? ` \xB7 ${Number(cnt[s.key].v).toLocaleString("sr-RS")} RSD` : ""}</span></a>`).join("");
  const t = today();
  const rows = leads.map((l, i) => `<tr>
    <td class="muted">${i + 1}</td>
    <td><b style="font-size:1.05rem">${l.score || 0}</b> ${prio(l.priority)}</td>
    <td><a href="/admin/leads/${l.id}"><b>${esc(l.company)}</b></a><div class="muted">${esc(l.sector || SEGMENTS[l.segment] || l.segment)}${l.city ? " \xB7 " + esc(l.city) : ""}${l.employees ? " \xB7 " + esc(l.employees) : ""}${l.source === "sajt" ? ' \xB7 <span class="tag">sa sajta</span>' : ""}</div>${l.score_why ? `<div class="muted" style="font-size:.8rem;max-width:520px">${esc(l.score_why)}</div>` : ""}</td>
    <td>${esc(l.contact_name || "")}${l.contact_role ? `<div class="muted">${esc(l.contact_role)}</div>` : ""}</td>
    <td>${l.email ? `<a href="mailto:${esc(l.email)}">${esc(l.email)}</a>` : '<span class="muted">\u2014</span>'}${l.phone ? `<div class="muted">${esc(l.phone)}</div>` : ""}</td>
    <td>${pill(l.status)}</td>
    <td class="${l.next_action_at && l.next_action_at < t ? "late" : ""}">${esc(fmtDate(l.next_action_at))}</td>
    <td>${l.value_rsd ? Number(l.value_rsd).toLocaleString("sr-RS") + " RSD" : ""}</td></tr>`).join("");
  return page("Leadovi", `<h1>Leadovi</h1><div class="pipe"><a href="/admin${segment ? `?segment=${segment}` : ""}" class="${!status ? "on" : ""}"><b>${leads.length}</b><span class="muted">Aktivni prikaz</span></a>${pipe}</div>
    <form class="inline" method="get"><input type="hidden" name="status" value="${esc(status)}">
    <label><span>Pretraga</span><input name="q" value="${esc(q)}" placeholder="firma, ime, grad\u2026"></label>
    <label><span>Segment</span><select name="segment"><option value="">Svi</option>${options(Object.entries(SEGMENTS), segment)}</select></label>
    <label><span>Prioritet</span><select name="priority"><option value="">Svi</option>${options([["A", "A \u2014 dokazana praksa / topla veza"], ["B", "B \u2014 veliki / family-friendly"], ["C", "C \u2014 mogu\u0107e"], ["X", "X \u2014 uga\u0161eno"]], priority)}</select></label>
    <label><span>Region</span><select name="region"><option value="">Svi</option>${options(regions.map((r) => [r.region, `${r.region} (${r.n})`]), region)}</select></label>
    <label><span>Redosled</span><select name="sort">${options([["skor", "Po skoru (najverovatniji prvi)"], ["sledeci", "Po datumu slede\u0107eg koraka"]], sort)}</select></label>
    <button class="btn ghost">Filtriraj</button><a class="btn" href="/admin/leads/new">+ Novi lead</a></form>
    <table><thead><tr><th>#</th><th>Skor</th><th>Organizacija</th><th>Kontakt osoba</th><th>Kontakt</th><th>Status</th><th>Slede\u0107i korak</th><th>Vrednost</th></tr></thead>
    <tbody>${rows || '<tr><td colspan="8" class="muted">Nema leadova za ovaj filter.</td></tr>'}</tbody></table>`, { flash, err });
}
function leadFields(l) {
  const v = (k) => esc(l?.[k] ?? "");
  return `<label><span>Naziv firme / ustanove *</span><input name="company" required value="${v("company")}"></label>
  <div class="row3"><label><span>Segment</span><select name="segment">${options(Object.entries(SEGMENTS), l?.segment || "firma")}</select></label>
  <label><span>Grad</span><input name="city" value="${v("city")}"></label>
  <label><span>Broj zaposlenih</span><input name="employees" value="${v("employees")}" placeholder="npr. 200+"></label></div>
  <div class="row"><label><span>Kontakt osoba</span><input name="contact_name" value="${v("contact_name")}"></label>
  <label><span>Funkcija</span><input name="contact_role" value="${v("contact_role")}" placeholder="npr. HR menad\u017Eer"></label></div>
  <div class="row"><label><span>Imejl</span><input type="email" name="email" value="${v("email")}"></label>
  <label><span>Telefon</span><input name="phone" value="${v("phone")}"></label></div>
  <div class="row"><label><span>Sajt</span><input name="website" value="${v("website")}"></label>
  <label><span>Izvor</span><select name="source">${options([["rucno", "Ru\u010Dno / istra\u017Eivanje"], ["sajt", "Upit sa sajta"], ["preporuka", "Preporuka"], ["linkedin", "LinkedIn"], ["instagram", "Instagram"], ["dogadjaj", "Doga\u0111aj / sajam"], ["postojeci", "Postoje\u0107i klijent"]], l?.source || "rucno")}</select></label></div>
  <div class="row3"><label><span>Status</span><select name="status">${options(STATUSES.map((s) => [s.key, s.label]), l?.status || "za_kontakt")}</select></label>
  <label><span>Slede\u0107i korak (datum)</span><input type="date" name="next_action_at" value="${v("next_action_at")}"></label>
  <label><span>Vrednost ponude (RSD)</span><input type="number" name="value_rsd" value="${v("value_rsd")}"></label></div>
  <div class="row3"><label><span>Prioritet</span><select name="priority">${options([["", "\u2014"], ["A", "A"], ["B", "B"], ["C", "C"], ["X", "X (uga\u0161eno)"]], l?.priority || "")}</select></label>
  <label><span>Kanal pristupa</span><input name="channel" value="${v("channel")}" placeholder="HR, sindikat, uprava\u2026"></label>
  <label><span>Predlo\u017Eeni paket</span><input name="package" value="${v("package")}"></label></div>
  <label><span>Predlo\u017Eeni program</span><input name="program" value="${v("program")}"></label>
  <label><span>Za\u0161to je lead (argument za razgovor)</span><textarea name="reason" style="min-height:60px">${v("reason")}</textarea></label>
  <div class="row"><label><span>LinkedIn firme</span><input name="linkedin" value="${v("linkedin")}"></label>
  <label><span>Kontakt forma (URL)</span><input name="contact_url" value="${v("contact_url")}"></label></div>
  <label><span>Bele\u0161ke</span><textarea name="notes">${v("notes")}</textarea></label>
  <label class="check"><input type="checkbox" name="marketing_consent" value="1"${l?.marketing_consent ? " checked" : ""}> Dao/la saglasnost za novosti i kampanje</label>`;
}
function readLead(fd) {
  const out = {};
  for (const f of LEAD_FIELDS) {
    const raw = clean(fd.get(f), f === "notes" || f === "reason" ? 5e3 : 300);
    if (f === "value_rsd") out[f] = raw ? Number(raw.replace(/\D/g, "")) || null : null;
    else if (f === "marketing_consent") out[f] = fd.get(f) ? 1 : 0;
    else out[f] = raw || null;
  }
  if (out.email) out.email = String(out.email).toLowerCase();
  if (!out.segment) out.segment = "firma";
  if (!out.status) out.status = "za_kontakt";
  if (!out.source) out.source = "rucno";
  return out;
}
function leadForm(l, _env, err) {
  return page("Novi lead", `<h1>Novi lead</h1><div class="card" style="max-width:820px"><form method="post" action="/admin/leads/new">${leadFields(l)}<button class="btn">Sa\u010Duvaj</button></form></div>`, { err });
}
async function createLead(req, env) {
  const data = readLead(await req.formData());
  if (!data.company) return leadForm(null, env, "Naziv je obavezan.");
  try {
    const cols = Object.keys(data);
    const r = await env.DB.prepare(`INSERT INTO leads (${cols.join(",")}) VALUES (${cols.map(() => "?").join(",")})`).bind(...Object.values(data)).run();
    return redirect(`/admin/leads/${r.meta.last_row_id}?ok=Lead+je+sa\u010Duvan`);
  } catch (e) {
    return leadForm(data, env, String(e).includes("UNIQUE") ? "Lead sa ovim imejlom ve\u0107 postoji." : "Gre\u0161ka pri \u010Duvanju.");
  }
}
async function leadDetail(id, env, flash, err) {
  const lead = await env.DB.prepare("SELECT * FROM leads WHERE id = ?").bind(id).first();
  if (!lead) return page("Nije prona\u0111eno", "<h1>Lead ne postoji</h1>");
  const { results: acts } = await env.DB.prepare("SELECT * FROM activities WHERE lead_id = ? ORDER BY created_at DESC, id DESC").bind(id).all();
  const tl = acts.map((a) => `<li class="${esc(a.kind)}"><b>${esc(a.subject || a.kind)}</b> <span class="muted">\xB7 ${esc(fmtDate(a.created_at))}</span>${a.body ? `<pre>${esc(a.body)}</pre>` : ""}</li>`).join("");
  const defaultTpl = lead.segment === "vrtic" ? "vrtic" : "prvi-kontakt";
  const tplOpts = options(templates.map((t) => [t.key, t.label]), defaultTpl);
  const first = (lead.contact_name || "").split(" ")[0];
  const canSend = !!lead.email;
  return page(lead.company, `<div class="actions" style="justify-content:space-between;margin-bottom:12px"><h1 style="margin:0">${esc(lead.company)} ${pill(lead.status)}</h1><a href="/admin" class="btn ghost sm">\u2190 Svi leadovi</a></div>
  <div class="grid g2">
    <div class="card"><h2>Podaci</h2><form method="post" action="/admin/leads/${id}">${leadFields(lead)}<div class="actions"><button class="btn">Sa\u010Duvaj izmene</button><span class="muted">Dodat ${esc(fmtDate(lead.created_at))}</span></div></form>
      <form method="post" action="/admin/leads/${id}/delete" onsubmit="return confirm('Obrisati lead i celu istoriju?')" style="margin-top:14px"><button class="btn ghost sm">Obri\u0161i lead</button></form></div>
    <div class="grid" style="align-content:start">
      <div class="card" style="border-left:4px solid ${PRIORITY_COLORS[lead.priority || ""] || "var(--line)"}"><h2>Za\u0161to ih zovemo ${prio(lead.priority)} <span class="muted">skor ${lead.score || 0}</span></h2>
        ${lead.reason ? `<p style="margin:0 0 8px">${esc(lead.reason)}</p>` : ""}
        ${lead.score_why ? `<p class="muted" style="margin:0 0 8px">${esc(lead.score_why)}</p>` : ""}
        <div class="actions">${[
    lead.evidence_url && `<a class="btn ghost sm" target="_blank" rel="noopener" href="${esc(lead.evidence_url)}">Dokaz / izvor</a>`,
    lead.linkedin && /^https?:/.test(lead.linkedin) && `<a class="btn ghost sm" target="_blank" rel="noopener" href="${esc(lead.linkedin)}">LinkedIn \u2192 na\u0111i HR</a>`,
    lead.contact_url && /^https?:/.test(lead.contact_url) && `<a class="btn ghost sm" target="_blank" rel="noopener" href="${esc(lead.contact_url)}">Kontakt forma</a>`,
    lead.website && `<a class="btn ghost sm" target="_blank" rel="noopener" href="${esc(/^https?:/.test(lead.website) ? lead.website : "https://" + lead.website)}">Sajt</a>`
  ].filter(Boolean).join("")}</div>
        ${lead.channel || lead.program ? `<p class="muted" style="margin:10px 0 0">${lead.channel ? `Kanal: <b>${esc(lead.channel)}</b>` : ""}${lead.program ? ` \xB7 Program: <b>${esc(lead.program)}</b>` : ""}${lead.package ? ` \xB7 Paket: <b>${esc(lead.package)}</b>` : ""}</p>` : ""}
      </div>
      <div class="card"><h2>Po\u0161alji mejl</h2>${canSend ? `
        <form method="post" action="/admin/leads/${id}/email">
          <label><span>\u0160ablon</span><select name="template" id="tpl">${tplOpts}</select></label>
          <label><span>Ime u pozdravu</span><input name="ime" value="${esc(first)}" placeholder="prazno = \u201EPo\u0161tovani,\u201C"></label>
          <label><span>Li\u010Dna re\u010Denica na po\u010Detku (opciono)</span><textarea name="licno" placeholder="npr. Videli smo da ste nedavno organizovali Dan porodice\u2026"></textarea></label>
          <label><span>Naslov (opciono \u2014 prazno = iz \u0161ablona)</span><input name="subject"></label>
          <div class="actions"><button class="btn" onclick="return confirm('Poslati mejl na ${esc(lead.email)}?')">Po\u0161alji na ${esc(lead.email)}</button>
          <a class="btn ghost sm" target="_blank" id="pv" href="/admin/templates/${defaultTpl}?lead=${id}">Pregled</a></div>
        </form>
        <script>document.getElementById('tpl').addEventListener('change',e=>{document.getElementById('pv').href='/admin/templates/'+e.target.value+'?lead=${id}'})<\/script>` : '<p class="muted">Dodaj imejl kontakt osobe da bi mogao da \u0161alje\u0161 mejlove.</p>'}
      </div>
      <div class="card"><h2>Bele\u0161ka / poziv</h2><form method="post" action="/admin/leads/${id}/note">
        <div class="row"><label><span>Tip</span><select name="kind">${options([["napomena", "Bele\u0161ka"], ["poziv", "Poziv"], ["sastanak", "Sastanak"]])}</select></label>
        <label><span>Slede\u0107i korak</span><input type="date" name="next_action_at" value="${esc(lead.next_action_at || "")}"></label></div>
        <label><span>\u0160ta je dogovoreno</span><textarea name="body" required></textarea></label><button class="btn">Dodaj</button></form></div>
      <div class="card"><h2>Istorija</h2><ul class="tl">${tl || "<li>Jo\u0161 nema aktivnosti.</li>"}</ul></div>
    </div></div>`, { flash, err });
}
async function updateLead(id, req, env) {
  const before = await env.DB.prepare("SELECT status FROM leads WHERE id = ?").bind(id).first();
  if (!before) return redirect("/admin");
  const data = readLead(await req.formData());
  const sets = Object.keys(data).map((k) => `${k} = ?`).join(", ");
  try {
    await env.DB.prepare(`UPDATE leads SET ${sets}, updated_at = datetime('now') WHERE id = ?`).bind(...Object.values(data), id).run();
  } catch (e) {
    return redirect(`/admin/leads/${id}?err=${encodeURIComponent(String(e).includes("UNIQUE") ? "Drugi lead ve\u0107 ima ovaj imejl." : "Gre\u0161ka pri \u010Duvanju.")}`);
  }
  if (before.status !== data.status) {
    await env.DB.prepare(`INSERT INTO activities (lead_id, kind, subject) VALUES (?, 'status', ?)`).bind(id, `Status: ${statusOf(before.status).label} \u2192 ${statusOf(String(data.status)).label}`).run();
  }
  return redirect(`/admin/leads/${id}?ok=Sa\u010Duvano`);
}
async function addNote(id, req, env) {
  const fd = await req.formData();
  const kind = clean(fd.get("kind"), 20) || "napomena";
  const body = clean(fd.get("body"), 5e3);
  const next = clean(fd.get("next_action_at"), 10);
  const labels = { napomena: "Bele\u0161ka", poziv: "Poziv", sastanak: "Sastanak" };
  if (body) await env.DB.prepare("INSERT INTO activities (lead_id, kind, subject, body) VALUES (?, ?, ?, ?)").bind(id, kind, labels[kind] || "Bele\u0161ka", body).run();
  await env.DB.prepare(`UPDATE leads SET next_action_at = ?, updated_at = datetime('now'),
    status = CASE WHEN ? IN ('poziv','sastanak') AND status IN ('novo','za_kontakt','kontaktiran') THEN 'u_razgovoru' ELSE status END WHERE id = ?`).bind(next || null, kind, id).run();
  return redirect(`/admin/leads/${id}?ok=Dodato`);
}
async function sendLeadEmail(id, req, env) {
  const lead = await env.DB.prepare("SELECT * FROM leads WHERE id = ?").bind(id).first();
  if (!lead?.email) return redirect(`/admin/leads/${id}?err=Lead+nema+imejl`);
  const fd = await req.formData();
  const tpl = templateByKey(clean(fd.get("template"), 40));
  if (!tpl) return redirect(`/admin/leads/${id}?err=Nepoznat+\u0161ablon`);
  const vars = { ime: clean(fd.get("ime"), 80), firma: lead.company, grad: lead.city || "", licno: clean(fd.get("licno"), 2e3) };
  const mail = renderTemplate(tpl, vars, siteUrl(env), clean(fd.get("subject"), 200) || void 0);
  const res = await sendEmail(env, { to: lead.email, subject: mail.subject, html: mail.html, text: mail.text, tags: [{ name: "template", value: tpl.key }, { name: "lead", value: String(id) }] });
  if (!res.ok) return redirect(`/admin/leads/${id}?err=${encodeURIComponent(res.error || "Slanje nije uspelo")}`);
  await env.DB.prepare(`INSERT INTO activities (lead_id, kind, subject, body, meta) VALUES (?, 'mejl', ?, ?, ?)`).bind(id, `Mejl: ${mail.subject}`, vars.licno || null, JSON.stringify({ template: tpl.key, id: res.id })).run();
  const followUp = new Date(Date.now() + 5 * 864e5).toISOString().slice(0, 10);
  await env.DB.prepare(`UPDATE leads SET updated_at = datetime('now'),
      status = CASE WHEN status IN ('novo','za_kontakt') THEN 'kontaktiran' ELSE status END,
      next_action_at = CASE WHEN next_action_at IS NULL OR next_action_at = '' OR next_action_at < date('now') THEN ? ELSE next_action_at END
    WHERE id = ?`).bind(followUp, id).run();
  return redirect(`/admin/leads/${id}?ok=${encodeURIComponent(`Mejl poslat na ${lead.email}. Podsetnik za follow-up: ${followUp}`)}`);
}
async function deleteLead(id, env) {
  await env.DB.batch([env.DB.prepare("DELETE FROM activities WHERE lead_id = ?").bind(id), env.DB.prepare("DELETE FROM leads WHERE id = ?").bind(id)]);
  return redirect("/admin?ok=Lead+obrisan");
}
function templatesPage(env) {
  const rows = templates.map((t) => `<tr><td><b>${esc(t.label)}</b><div class="muted">${esc(t.subject)}</div></td><td>${esc(SEGMENTS[t.audience] || "Svi")}</td><td><a class="btn ghost sm" target="_blank" href="/admin/templates/${t.key}">Pregled</a></td></tr>`).join("");
  return page("Mejl \u0161abloni", `<h1>Mejl \u0161abloni</h1><p class="muted">\u0160abloni se \u0161alju iz kartice leada. Tekst menja\u0161 u <code>worker/emails.ts</code>. Slanje: ${env.RESEND_API_KEY ? '<b style="color:#5c8f22">Resend povezan</b>' : '<b style="color:#d92d20">Resend nije pode\u0161en</b>'}.</p>
    <table><thead><tr><th>\u0160ablon</th><th>Za</th><th></th></tr></thead><tbody>${rows}</tbody></table>`);
}
async function previewTemplate(key, url, env) {
  const tpl = templateByKey(key);
  if (!tpl) return page("Nije prona\u0111eno", "<h1>\u0160ablon ne postoji</h1>");
  let vars = { ime: "Marija", firma: "Primer d.o.o.", grad: "Kragujevac" };
  const leadId = Number(url.searchParams.get("lead"));
  if (leadId) {
    const l = await env.DB.prepare("SELECT company, contact_name, city FROM leads WHERE id = ?").bind(leadId).first();
    if (l) vars = { ime: (l.contact_name || "").split(" ")[0], firma: l.company, grad: l.city || "" };
  }
  const mail = renderTemplate(tpl, vars, siteUrl(env));
  return new Response(mail.html.replace("<body", `<body data-subject="${esc(mail.subject)}"`).replace('<table role="presentation" width="100%"', `<div style="max-width:600px;margin:16px auto 0;font-family:Arial;font-size:14px;color:#3d5368"><b>Naslov:</b> ${esc(mail.subject)}</div><table role="presentation" width="100%"`), {
    headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" }
  });
}
var CSV_COLS = ["firma", "segment", "grad", "kontakt", "funkcija", "email", "telefon", "sajt", "zaposleni", "napomena", "prioritet", "skor", "region", "sektor", "kanal", "program", "paket", "zasto", "dokaz", "linkedin", "kontakt_forma", "skor_obrazlozenje"];
function importForm(flash, err) {
  return page("Uvoz liste", `<h1>Uvoz liste firmi</h1><div class="card" style="max-width:900px">
    <p>Nalepi CSV (iz Excel/Google Sheets: <i>File \u2192 Download \u2192 CSV</i>). Prvi red su nazivi kolona:</p>
    <p><code>${CSV_COLS.join(",")}</code></p>
    <p class="muted">Obavezna je samo kolona <b>firma</b>. Segment: firma, vrtic, institucija, rodjendaonica, roditelj. Firme koje ve\u0107 postoje (isti imejl ili isti naziv) se preska\u010Du.</p>
    <form method="post"><label><span>CSV</span><textarea name="csv" style="min-height:260px;font-family:monospace" placeholder="firma,segment,grad,kontakt,funkcija,email,telefon,sajt,zaposleni,napomena&#10;Primer d.o.o.,firma,Kragujevac,Ana Ani\u0107,HR menad\u017Eer,ana@primer.rs,,primer.rs,250,"></textarea></label>
    <button class="btn">Uvezi</button></form></div>`, { flash, err });
}
function parseCsv(text) {
  const rows = [];
  let row = [], cell = "", q = false;
  const sep = (text.split("\n")[0].match(/;/g)?.length || 0) > (text.split("\n")[0].match(/,/g)?.length || 0) ? ";" : ",";
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"' && text[i + 1] === '"') {
        cell += '"';
        i++;
      } else if (c === '"') q = false;
      else cell += c;
    } else if (c === '"') q = true;
    else if (c === sep) {
      row.push(cell);
      cell = "";
    } else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else cell += c;
  }
  if (cell || row.length) {
    row.push(cell);
    rows.push(row);
  }
  return rows.filter((r) => r.some((x) => x.trim()));
}
async function importCsv(req, env) {
  const fd = await req.formData();
  const rows = parseCsv(clean(fd.get("csv"), 5e5));
  if (rows.length < 2) return importForm(void 0, "CSV mora imati red sa nazivima kolona i bar jedan red podataka.");
  const head = rows[0].map((h) => h.trim().toLowerCase());
  const idx = (k) => head.indexOf(k);
  if (idx("firma") < 0) return importForm(void 0, "Nedostaje kolona \u201Efirma\u201C.");
  const { results: existing } = await env.DB.prepare("SELECT lower(company) AS c, lower(email) AS e FROM leads").all();
  const names = new Set(existing.map((x) => x.c));
  const emails = new Set(existing.map((x) => x.e).filter(Boolean));
  const stmts = [];
  let skipped = 0;
  for (const r of rows.slice(1)) {
    const g = (k) => idx(k) >= 0 ? (r[idx(k)] || "").trim() : "";
    const company = g("firma");
    const email = g("email").toLowerCase();
    if (!company || names.has(company.toLowerCase()) || email && emails.has(email)) {
      skipped++;
      continue;
    }
    names.add(company.toLowerCase());
    if (email) emails.add(email);
    const seg = SEGMENTS[g("segment")] ? g("segment") : "firma";
    const pr = g("prioritet").toUpperCase();
    stmts.push(env.DB.prepare(`INSERT INTO leads (company, segment, city, contact_name, contact_role, email, phone, website, employees, notes, source, status,
        priority, score, region, sector, channel, program, package, reason, evidence_url, linkedin, contact_url, score_why)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'rucno', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(
      company,
      seg,
      g("grad") || null,
      g("kontakt") || null,
      g("funkcija") || null,
      email || null,
      g("telefon") || null,
      g("sajt") || null,
      g("zaposleni") || null,
      g("napomena") || null,
      pr === "X" ? "izgubljeno" : "za_kontakt",
      pr || null,
      Number(g("skor")) || 0,
      g("region") || null,
      g("sektor") || null,
      g("kanal") || null,
      g("program") || null,
      g("paket") || null,
      g("zasto") || null,
      g("dokaz") || null,
      g("linkedin") || null,
      g("kontakt_forma") || null,
      g("skor_obrazlozenje") || null
    ));
  }
  for (let i = 0; i < stmts.length; i += 50) await env.DB.batch(stmts.slice(i, i + 50));
  return redirect(`/admin?ok=${encodeURIComponent(`Uvezeno ${stmts.length} leadova${skipped ? `, presko\u010Deno ${skipped} (duplikati/prazni)` : ""}.`)}`);
}
async function exportCsv(env) {
  const { results } = await env.DB.prepare("SELECT * FROM leads ORDER BY id").all();
  const cols = ["id", ...LEAD_FIELDS, "created_at", "updated_at"];
  const q = (v) => {
    const s = String(v ?? "");
    return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const csv = "\uFEFF" + [cols.join(","), ...results.map((l) => cols.map((c) => q(l[c])).join(","))].join("\n");
  return new Response(csv, { headers: { "content-type": "text/csv; charset=utf-8", "content-disposition": `attachment; filename="lumi-leadovi-${today()}.csv"`, "cache-control": "no-store" } });
}

// worker/index.ts
var index_default = {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.hostname.startsWith("www.")) {
      url.hostname = url.hostname.slice(4);
      return Response.redirect(url.toString(), 301);
    }
    if (url.pathname === "/api/inquiry") {
      if (request.method !== "POST") return new Response("Method Not Allowed", { status: 405, headers: { Allow: "POST" } });
      return handleInquiry(request, env);
    }
    if (url.pathname === "/admin" || url.pathname.startsWith("/admin/")) {
      return handleAdmin(request, env);
    }
    return env.ASSETS.fetch(request);
  }
};
export {
  index_default as default
};
